**************************************************************************************************************************								Project 1  
						Team Triple-T (Group 1) 
						Tic-Tac-Toe Game (GUI)
**************************************************************************************************************************
Game Features - 
1. User can view 3X3 Grid of Tic-Tac-Toe game. 

2. After first Player's move, the turn automatically switches to the other player and he places his symbol and so on.

3. A player can only mark his preference in an empty cell. 

4. Reset button is needed to clean the board like initial state.

5. Exit Button is needed if the player wants to exit the game.




Extra Game Features-
1. Upon initialization, game asks for player 1 and Player 2 name.

2. Asks for Player 1's symbol preference and automatically sets other symbol for Player 2.

3. The names of Player's entered during initial phase of the execution will be shown on the GUI 
   along with their respective symbols.	

4. Hover effect over buttons added [to make GUI more interactive] (hover effect - the user can point over any empty cell in    the grid and his symbol will temporarily appear until the mouse pointer is over that cell).
 
5. System Statistics button added so that user can determine memory usage of the game and time elapsed.

6. Help button has been implemented which shows game rules to the players.

7. Status bar has been added to GUI, to show time at which game was started.

8. Credits button added to show team information.



**************************************************************************************************************************
							Team Information.
**************************************************************************************************************************
	Amanjot Kaur Ahluwalia	-	40011623
	Arash Arasteh		-	40000580
	Arash Farkish		-	27678835
	Basireddy Sandeep Kumar	-	40016071
	Dalvir Singh Bains	-	40012722
	Nidhi Arora		-	40014504
	Parinaz Barakhshan	-	27675518
	Sarthak Batra		-	27408978